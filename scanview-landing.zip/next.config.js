/** @type {import('next').NextConfig} */
const nextConfig = {
  // SEO 최적화
  trailingSlash: false,
  
  // 이미지 최적화
  images: {
    domains: ['scanview.app'],
    formats: ['image/avif', 'image/webp'],
  },
  
  // 헤더 설정 (캐싱, 보안)
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
        ],
      },
      {
        // 정적 자산 캐싱
        source: '/(.*).(jpg|jpeg|png|gif|ico|svg|woff|woff2)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable',
          },
        ],
      },
    ]
  },
  
  // 리다이렉트 설정
  async redirects() {
    return [
      {
        source: '/home',
        destination: '/',
        permanent: true,
      },
    ]
  },
}

module.exports = nextConfig
