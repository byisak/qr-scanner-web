import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#1e293b',
}

export const metadata: Metadata = {
  metadataBase: new URL('https://scanview.app'),
  title: {
    default: 'QR Scanner Pro - 전문가용 QR코드 바코드 스캐너 앱',
    template: '%s | QR Scanner Pro',
  },
  description: '재고관리, 물류, 창고 업무에 최적화된 전문가용 QR코드 바코드 스캐너. 대량 스캔, 실시간 PC 전송, CSV 내보내기 지원.',
  applicationName: 'QR Scanner Pro',
  authors: [{ name: 'ScanView', url: 'https://scanview.app' }],
  creator: 'ScanView',
  publisher: 'ScanView',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  manifest: '/manifest.json',
  openGraph: {
    type: 'website',
    locale: 'ko_KR',
    url: 'https://scanview.app',
    siteName: 'QR Scanner Pro',
  },
  twitter: {
    card: 'summary_large_image',
    creator: '@scanviewapp',
  },
  verification: {
    google: 'YOUR_GOOGLE_VERIFICATION_CODE', // Google Search Console에서 발급
    // yandex: 'YOUR_YANDEX_CODE',
    // bing: 'YOUR_BING_CODE',
  },
  category: 'business',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ko">
      <head>
        {/* 추가 SEO 태그들 */}
        <link rel="canonical" href="https://scanview.app" />
        <meta name="theme-color" content="#1e293b" />
        
        {/* 소셜 미디어 추가 메타 태그 */}
        <meta property="og:locale:alternate" content="en_US" />
        
        {/* 앱 링크 메타 태그 - 앱 설치 유도 */}
        <meta name="apple-itunes-app" content="app-id=YOUR_APP_ID" />
        <meta name="google-play-app" content="app-id=com.scanview.qrscanner" />
        
        {/* DNS Prefetch for performance */}
        <link rel="dns-prefetch" href="//fonts.googleapis.com" />
        <link rel="dns-prefetch" href="//www.googletagmanager.com" />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
