import { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/api/', '/app/'], // 웹앱은 검색에서 제외 (원하면 제거)
      },
      {
        userAgent: 'GPTBot', // ChatGPT 크롤러
        allow: '/',
      },
      {
        userAgent: 'Google-Extended', // Google AI (Bard/Gemini)
        allow: '/',
      },
      {
        userAgent: 'anthropic-ai', // Claude 크롤러 (있다면)
        allow: '/',
      },
      {
        userAgent: 'CCBot', // Common Crawl (AI 학습용)
        allow: '/',
      },
    ],
    sitemap: 'https://scanview.app/sitemap.xml',
  }
}
