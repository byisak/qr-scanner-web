import { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://scanview.app'
  
  // 정적 페이지들
  const staticPages = [
    '',
    '/features',
    '/pricing',
    '/blog',
    '/support',
    '/docs',
    '/privacy',
    '/terms',
  ]

  // 블로그 포스트들 (나중에 동적으로 가져올 수 있음)
  const blogPosts = [
    'best-qr-scanner-apps-2024',
    'inventory-management-barcode-guide',
    'qr-code-vs-barcode-difference',
    'warehouse-efficiency-mobile-scanning',
    'barcode-types-explained',
    'real-time-inventory-tracking',
  ]

  const staticEntries = staticPages.map((page) => ({
    url: `${baseUrl}${page}`,
    lastModified: new Date(),
    changeFrequency: page === '' ? 'weekly' : 'monthly' as const,
    priority: page === '' ? 1 : 0.8,
  }))

  const blogEntries = blogPosts.map((slug) => ({
    url: `${baseUrl}/blog/${slug}`,
    lastModified: new Date(),
    changeFrequency: 'monthly' as const,
    priority: 0.7,
  }))

  return [...staticEntries, ...blogEntries]
}
