# QR Scanner Pro 랜딩페이지 SEO 최적화 가이드

## 📁 프로젝트 구조

```
scanview-landing/
├── app/
│   ├── page.tsx              # 메인 랜딩페이지
│   ├── layout.tsx            # 전역 레이아웃 + SEO 메타데이터
│   ├── globals.css           # 전역 스타일
│   ├── sitemap.ts            # 자동 사이트맵 생성
│   ├── robots.ts             # robots.txt 설정
│   └── blog/
│       ├── page.tsx          # 블로그 목록
│       └── best-qr-scanner-apps-2024/
│           └── page.tsx      # 블로그 포스트 예시
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── postcss.config.js
└── next.config.js
```

## 🚀 배포 방법

### 기존 scanview.app 프로젝트에 통합하기

1. **파일 복사**
   - `app/page.tsx` → 기존 프로젝트의 랜딩페이지로 사용
   - `app/blog/` 폴더 전체 복사
   - `app/sitemap.ts`, `app/robots.ts` 복사

2. **메타데이터 업데이트**
   - `layout.tsx`의 metadata 내용을 기존 레이아웃에 병합
   - Google Search Console 인증 코드 추가

3. **의존성 설치**
   ```bash
   npm install lucide-react @tailwindcss/typography
   ```

4. **빌드 및 배포**
   ```bash
   npm run build
   pm2 restart your-app
   ```

## ✅ SEO 체크리스트

### 기본 설정
- [ ] Google Search Console 등록
- [ ] 사이트맵 제출 (https://scanview.app/sitemap.xml)
- [ ] Google Analytics 설치
- [ ] favicon, apple-touch-icon 추가

### 메타 태그
- [x] title 태그 (60자 이내)
- [x] meta description (160자 이내)
- [x] Open Graph 태그
- [x] Twitter Card 태그
- [x] canonical URL
- [x] hreflang (다국어)

### 구조화 데이터
- [x] SoftwareApplication JSON-LD
- [x] FAQPage JSON-LD
- [x] Article JSON-LD (블로그)
- [ ] Organization JSON-LD

### 콘텐츠
- [x] H1 태그 (페이지당 1개)
- [x] 계층적 헤딩 구조 (H1 > H2 > H3)
- [x] 키워드 포함된 URL
- [x] 내부 링크
- [ ] 이미지 alt 태그

### 기술적 SEO
- [x] robots.txt
- [x] sitemap.xml
- [x] HTTPS
- [ ] 페이지 속도 최적화
- [ ] 모바일 최적화

## 🤖 AI 검색 최적화 (AIO) 전략

### 1. 구조화된 FAQ
FAQ 섹션은 AI가 답변을 생성할 때 참조하기 좋은 형식입니다.
- JSON-LD FAQPage 스키마 적용 완료
- 자연스러운 질문-답변 형식 사용

### 2. 비교 콘텐츠
`/blog/best-qr-scanner-apps-2024` 같은 비교 글은 AI가 추천할 때 참조하기 좋습니다.
- "Best QR scanner app for inventory" 같은 쿼리에 노출

### 3. 키워드 전략
**타겟 키워드:**
- QR코드 스캐너 앱
- 바코드 스캐너 앱
- 재고관리 앱
- 물류 바코드 스캐너
- 창고 QR 스캐너

**롱테일 키워드:**
- 재고관리용 QR 스캐너 앱 추천
- 무료 바코드 스캐너 앱 비교
- PC 연동 QR 스캐너

### 4. 외부 링크 전략
다음 사이트에 등록/홍보하세요:
- [ ] Product Hunt
- [ ] AlternativeTo.net
- [ ] G2.com
- [ ] Capterra
- [ ] GetApp
- [ ] Reddit (r/selfhosted, r/smallbusiness)
- [ ] 네이버 블로그
- [ ] velog
- [ ] Medium

## 📊 성과 측정

### Google Search Console
- 검색 노출수, 클릭수 추적
- 키워드별 순위 확인
- 인덱싱 상태 모니터링

### 추천 도구
- Ahrefs / SEMrush - 키워드 분석
- PageSpeed Insights - 속도 측정
- Mobile-Friendly Test - 모바일 최적화

## 🔄 지속적인 개선

1. **블로그 콘텐츠 추가** (월 2-4개)
   - 재고관리 팁
   - 바코드 기술 설명
   - 사용 사례 (케이스 스터디)

2. **사용자 리뷰 수집**
   - 앱스토어 리뷰 유도
   - 웹사이트에 리뷰 표시

3. **소셜 미디어 활동**
   - 제품 업데이트 공유
   - 사용 팁 콘텐츠

---

## 문의
추가 질문이나 개선 사항은 언제든 말씀해주세요!
